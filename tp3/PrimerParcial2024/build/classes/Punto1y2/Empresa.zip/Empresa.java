package Punto1y2;

import java.util.Objects;

/**
 *
 * @author Ariel Sebastián Andrés
 */
public class Empresa extends Cliente {

    private String razonSocial; //Nombre de la empresa
    private boolean ivaExento;

    public Empresa(String razonSocial, boolean ivaExento, int id, Plan plan) {
        super(id, plan);
        this.razonSocial = razonSocial;
        this.ivaExento = ivaExento;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public boolean isIvaExento() {
        return ivaExento;
    }

    public void setIvaExento(boolean ivaExento) {
        this.ivaExento = ivaExento;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    @Override
    public String toString() {
        return "Empresa{" + "razonSocial=" + razonSocial + ", ivaExento=" + ivaExento + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empresa other = (Empresa) obj;
        if (this.ivaExento != other.ivaExento) {
            return false;
        }
        return Objects.equals(this.razonSocial, other.razonSocial);
    }
}
