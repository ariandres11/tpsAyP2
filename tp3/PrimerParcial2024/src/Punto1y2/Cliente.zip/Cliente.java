package Punto1y2;

/**
 *
 * @author Ariel Sebastián Andrés
 */
public class Cliente {

    private int id;
    private static final double IVA = 21;
    private static String direccion;
    //Un cliente tiene un plan
    public Plan plan;

    public Cliente() {
    }

    public Cliente(int id, Plan plan) {
        this.id = id;
        this.plan = plan;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static String getDireccion() {
        return direccion;
    }

    public static void setDireccion(String direccion) {
        Cliente.direccion = direccion;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    @Override
    public String toString() {
        return "Cliente{" + "id=" + id + ", plan=" + plan + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        return this.id == other.id;
    }

    public double calcularFactura() {
        double tarifa = this.plan.getTarifa();
        double total;
        if (this instanceof Persona) {
            total = tarifa + ((tarifa / 100) * IVA);
            return total;
        } else {
            if (this instanceof Empresa) {
                Empresa empresa = (Empresa) this;
                if (empresa.isIvaExento()) {
                    //No sumar iva
                    return tarifa;
                } else {
                    total = tarifa + ((tarifa / 100) * IVA);
                    return total;
                }
            }
        }
        return 0;
    }
}
