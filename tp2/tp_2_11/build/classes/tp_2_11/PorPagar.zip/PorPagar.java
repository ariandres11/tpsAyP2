
package tp_2_11;

public interface PorPagar {
    
    public double obtenerPago();
    
}
